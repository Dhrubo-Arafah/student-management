from django.contrib import admin
from portal.models import *

admin.site.register(Student)

from django.shortcuts import render, redirect
from portal.models import *


def home(request):
    if request.method == 'GET':
        student = Student.objects.all();
        context = {
            'students': student
        }
        return render(request, 'index.html', context)

    elif request.method == 'POST':
        name = request.POST['name']
        var_id = request.POST['var_id']
        email = request.POST['email']

        Student.objects.create(name=name, var_id=var_id, email=email)
        return redirect('/')


def actionHandler(request, action, id):
    if action == 'delete':
        student = Student.objects.get(id=id)
        student.delete()
        return redirect('/')
    elif action == 'edit':
        if request.method == 'GET':
            student = Student.objects.get(id=id)
            context = {
                'student': student
            }
            return render(request, 'edit.html', context)

        if request.method == 'POST':
            name = request.POST['name']
            email = request.POST['email']
            var_id = request.POST['var_id']
            student = Student.objects.get(id=id)
            student.name = name
            student.email = email
            student.var_id = var_id

            student.save()
        return redirect('/')
